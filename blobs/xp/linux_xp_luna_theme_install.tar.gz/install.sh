#!/bin/bash
# Installs the XP Luna Theme for MATE GTK3
clear

echo -e "--------------\nLinux Luna XP Theme\n--------------\nLast Updated: 2/01/2014\nwww.winxp4life.tk\n"
echo -e "\nInstalling Luna Theme..."

sudo cp -r themes /usr/share/
sudo cp -r icons /usr/share/

# Copy luna background to the user using sudo picture directory
if [ ! -z "$SUDO_USER" ]; then
	if [ -e "/home/$SUDO_USER" ]; then
		if [ ! -e "/home/$SUDO_USER/Pictures" ]; then
			mkdir -p "/home/$SUDO_USER/Pictures"
		fi
		cp luna_background.jpg "/home/$SUDO_USER/Pictures"
	fi
fi

# Copy luna background to root user picture directory
if [ ! -d ~/Pictures ];
then
	mkdir ~/Pictures
fi

cp luna_background.jpg ~/Pictures

# Echo out

echo -e "\nSuccessfully copied the Luna theme files to the proper directories!"
echo -e
echo -e "The Luna default desktop wallpaper is located in your Pictures directory."
echo -e
echo -e "To install this theme and wallpaper, Right Click on your desktop and choose \"Change Desktop Background\""
echo -e
echo -e "Choose your Wallpaper image, then click on the Themes tab and select \"Luna\""
