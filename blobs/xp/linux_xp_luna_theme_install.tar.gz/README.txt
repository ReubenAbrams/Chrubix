-----------------------
Linux Luna XP Theme
-----------------------
Last Updated: 2/01/2014
www.winxp4life.tk

Changes:
	-  This version no longer uses the Unico theming engine. (2/01/2014)

	-  Theme should now work properly in Ubuntu 13.04 and Ubuntu 13.10
	-  Bug fixes in original GTK2 Theme for clock context menu and other widget context menu
	-  Theme should work properly in latest version of MATE 


-----------
Prerequisites:
-----------

GNOME2 or MATE Desktop Environment (Compatible with both GTK2 and GTK3)

MATE install Guide for Ubuntu:  http://ubuntu-tricks.com/install-mate-1-6-in-ubuntu/

-----------
To install:
-----------

The below instructions assume you have MATE or GNOME2 installed.

1. Run the install.sh script to make the Luna theme available to all users (requires sudo access). Or, run the install_local_user.sh to install the Luna theme for the current user only (sudo access NOT required).

2. After the install script exits, right click on your desktop and choose "Change Desktop Background".

3. If you want to use the default XP background, select the "luna_background.jpg" file located in your ~/Pictures directory.

4. Then click on the "Themes" tab and select "Luna"

The theme has been successfully installed.

-----------
Tested In:
-----------

Ubuntu 12.04 running MATE 1.6
Mint 13 running MATE 1.4

-----------
Credits:
-----------

Conversion to GTK3 by own3mall
Luna Theme Originally By: Casey Kirsle
Updated Version Released:  4/15/2013
